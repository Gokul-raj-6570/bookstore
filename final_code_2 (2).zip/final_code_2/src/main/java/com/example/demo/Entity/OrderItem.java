package com.example.demo.Entity;
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
 
@Entity
public class OrderItem {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private BookOrder order;
 
    @ManyToOne
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;
 
    private Integer quantity;
    private double price;
 
 
	public OrderItem() {
		super();
	}
 
 
	public OrderItem(Long id, BookOrder order, Book book, Integer quantity, int price) {
		super();
		this.id = id;
		this.order = order;
		this.book = book;
		this.quantity = quantity;
		this.price = price;
	}
 
 
	public Long getId() {
		return id;
	}
 
 
	public void setId(Long id) {
		this.id = id;
	}
 
 
	public BookOrder getOrder() {
		return order;
	}
 
 
	public void setOrder(BookOrder order) {
		this.order = order;
	}
 
 
	public Book getBook() {
		return book;
	}
 
 
	public void setBook(Book book) {
		this.book = book;
	}
 
 
	public Integer getQuantity() {
		return quantity;
	}
 
 
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
 
 
	
 
 
	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", order=" + order + ", book=" + book + ", quantity=" + quantity + ", price="
				+ price + "]";
	}
 
	
 
}