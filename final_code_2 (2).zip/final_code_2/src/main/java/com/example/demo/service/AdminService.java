package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Admin;
import com.example.demo.Repository.AdminRepository;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@Service
public class AdminService {
	@Autowired
	AdminRepository adminRepo;

	public Admin findByName(String adminname) {
		return adminRepo.findByAdminname(adminname);
	}

}
