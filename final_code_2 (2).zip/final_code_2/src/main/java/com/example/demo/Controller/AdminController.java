package com.example.demo.Controller;
 
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
 
import com.example.demo.Entity.Admin;
import com.example.demo.Entity.Book;
import com.example.demo.Entity.BookOrderStatus;
import com.example.demo.Entity.User;
import com.example.demo.service.AdminService;
import com.example.demo.service.BookService;
import com.example.demo.service.OrderService;
import com.example.demo.service.UserService;
 
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
 
 
@Controller
public class AdminController {
    @Autowired
    private AdminService adminService;
    @Autowired
    private UserService userService;
    @Autowired
    private BookService bookService;
    @Autowired
    private OrderService orderService;
    @GetMapping("/viewbooks")
    public String viewBook(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        if (session.getAttribute("adminId") == null) {
            return "redirect:/admin_login";
        }
        List<Book> books = bookService.allBooks(); 
        model.addAttribute("book", books); 
        return "viewbooks";
    }   

    @GetMapping("/admin_login")
    public String showAdminLoginForm() {
        return "admin_login";
    }
 
    @PostMapping("/admin_login")
    public String adminLogin(HttpServletRequest request, @RequestParam String adminname, @RequestParam String adminpassword, Model model) {
        Admin admin = adminService.findByName(adminname);
        if (admin != null && admin.getAdminpassword().equals(adminpassword)) {
            HttpSession session = request.getSession();
            session.setAttribute("adminId", admin.getId());
            return "redirect:/admin_home"; 
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "admin_login"; 
        }
    }

    @GetMapping("/viewusers")
    public String viewUsers(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        if (session.getAttribute("adminId") == null) {
            return "redirect:/admin_login";         }
        List<User> userList = userService.getUsers(); 
        model.addAttribute("users", userList); 
        return "viewusers";
    } 
    @GetMapping("/addbook")
    public String showAddCarForm(HttpServletRequest request) {
    	HttpSession session = request.getSession();
        if (session.getAttribute("adminId") == null) {
            return "redirect:/admin_login"; 
        }
        return "addbook";
    }
 
	  @PostMapping("/addbook")
	    public String addBook(@RequestParam String title, @RequestParam String description, @RequestParam double price,
	                          @RequestParam int quantity, @RequestParam String author, @RequestParam("image") MultipartFile image) {
	        try {
	            if (image.isEmpty()) {
	                return "redirect:/addbook?error=emptyfile";
	            }
	            if (image.getSize() > 10 * 1024 * 1024) { 
	                return "redirect:/addbook?error=filetoolarge";
	            }
	            byte[] imageData = image.getBytes();
	            String uploadDir = "src/main/resources/static/img/";
	            Path uploadPath = Paths.get(uploadDir);
	            if (!Files.exists(uploadPath)) {
	                Files.createDirectories(uploadPath);
	            }
	            String fileName = title + "-" + System.currentTimeMillis() + ".jpg"; 
	            Path filePath = uploadPath.resolve(fileName);
	            Files.write(filePath, imageData);
	            Book book = new Book();
	            book.setTitle(title);
	            book.setDescription(description);
	            book.setPrice(price);
	            book.setQuantity(quantity);
	            book.setAuthor(author);
	            book.setImage(imageData);
 
	            bookService.addNewBook(book);
	            return "addbook";
	        } catch (IOException e) {
	            e.printStackTrace();
	            return "redirect:/addbook?error=uploaderror";
	        }
	    }
	  @GetMapping("/books")
	    public String getAllBooks(Model model) {
	        List<Book> books = bookService.getAllBooks();
	        for (Book book : books) {
			      String imageBase64 = Base64.getEncoder().encodeToString(book.getImage());
			      book.setImageBase64(imageBase64);
			  }
	        model.addAttribute("book", books);
	        return "bookList"; 
	    }
 
	
    @GetMapping("/updatebook")
    public String showUpdateBookForm(HttpServletRequest request,Model model) {
    	HttpSession session = request.getSession();
        if (session.getAttribute("adminId") == null) {
            return "redirect:/admin_login"; 
        }
        List<Book> bookList = bookService.allBooks(); 
        model.addAttribute("book", bookList); 
        return "updatebook";
    }
 
    @GetMapping("/update_book_form")
    public String showEditCarForm(HttpServletRequest request,@RequestParam long bookId, Model model) {
    	HttpSession session = request.getSession();
        if (session.getAttribute("adminId") == null) {
            return "redirect:/admin_login"; 
        }
        Optional<Book> book = bookService.getBookById(bookId);
        model.addAttribute("book", book.orElse(null)); 
        return "update_book_form"; 
    }

    @PostMapping("/updatebook")
    public String updateBook(@RequestParam Long id, @RequestParam String title, @RequestParam String author,
                             @RequestParam String description, @RequestParam int quantity, @RequestParam double price,
                             Model model) {
        Optional<Book> optionalBook = bookService.getBookById(id);
        if (optionalBook.isPresent()) {
            Book book = optionalBook.get();
            book.setTitle(title);
            book.setAuthor(author);
            book.setDescription(description);
            book.setQuantity(quantity);
            book.setPrice(price);
            bookService.updateBook(book);
 
            if (quantity <= 0) {
                model.addAttribute("message", "Book is now out of stock");
                return "updatebook";
            }
 
            return "redirect:/updatebook";
        } else {
            model.addAttribute("error", "Book not found");
            return "out_of_stock"; 
        }
    }
    @GetMapping("/delete_book") 
    public String showdeleteBook(HttpServletRequest request,@RequestParam long bookId) {
    	HttpSession session = request.getSession();
        if (session.getAttribute("adminId") == null) {
            return "redirect:/admin_login"; 
        }
        bookService.deleteBook(bookId); 
        return "redirect:/updatebook"; 
    }
    @PostMapping("/delete_book")
    public String deleteBook(@RequestParam long bookId) {
        bookService.deleteBook(bookId); 
        return "redirect:/updatebook"; 
    }
 
    @GetMapping("/admin_home")
    public String adminHome() {
        return "admin_home";
    }
 
    @GetMapping("/manage_orders")
    public String manageOrders(Model model) {
        model.addAttribute("orders", orderService.getAllOrders());
        return "manage_orders";
    }
 
    @PostMapping("/update_order_status")
    public String updateOrderStatus(@RequestParam Long orderId, @RequestParam BookOrderStatus status) {
        orderService.updateOrderStatus(orderId, status);
        return "redirect:/manage_orders";
    }
    @GetMapping("/admin_logout")
    public String showLogoutConfirmation() {
        return "confirm_logout"; // Show the confirmation page
    }
 
    @PostMapping("/admin_logout")
    public String adminLogout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.invalidate(); // Invalidate the session to log out the admin
        return "redirect:/admin_login"; // Redirect to the login page after logout
    }
    @GetMapping("/adminsearch")
    public String searchBooks(@RequestParam("query") String query, Model model) {
        List<Book> searchResults = bookService.searchBooksByTitle(query);
        model.addAttribute("books", searchResults);
        return "book_list_admin"; // Thymeleaf fragment containing book list
    }
 
}
