package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.CartEntity;
import com.example.demo.Entity.User;
import com.example.demo.Repository.CartRepository;
import com.example.demo.Repository.UserRepository;

import jakarta.transaction.Transactional;


@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private UserRepository userRepository;

    public CartEntity getCartByUserId(Long userId) {
        Optional<User> user = userRepository.findById(userId);
        return user.map(User::getShoppingCart).orElse(null);
    }

    public void save(CartEntity cart) {
        cartRepository.save(cart);
    }

    @Transactional
    public void clearCart(CartEntity cart) {
        cart.getItems().clear(); // Remove all items from the cart
        cartRepository.save(cart); // Save the updated cart to the database
    }


}