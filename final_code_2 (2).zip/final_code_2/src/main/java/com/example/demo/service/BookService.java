package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Book;
import com.example.demo.Repository.BookRepository;



@Service
public class BookService {
	
	@Autowired
	BookRepository bookRepo;

	public Book updateBook(Long id, Book book) {
		Book existBook = bookRepo.findById(id).orElse(null);

        if (existBook != null) {
            
            existBook.setQuantity(book.getQuantity());
            bookRepo.save(existBook);
    
            return existBook;
        } else { 
            return null;
        }
	}


	public Optional<Book> getBookById(long bookId) {
		return bookRepo.findById(bookId);
	}

	
	public void addNewBook(Book book) {
		bookRepo.save(book);
		
	}

	public void deleteBook(long bookId) {
		bookRepo.deleteById(bookId);
		
	}

	public void updateBook(Book book) {
		bookRepo.save(book);
		
	}

	public List<Book> allBooks() {
		return bookRepo.findAll();
	}


	public List<Book> getBooks() {
		return bookRepo.findAll();
	}


	public Optional<Book> findById(Long bookId) {
		return bookRepo.findById(bookId);
	}


	public List<Book> getAllBooks() {
		return bookRepo.findAll();
	}

    public List<Book> searchBooks(String query) {
        List<Book> allBooks = bookRepo.findAll();
        return allBooks.stream()
                .filter(book -> containsIgnoreCase(book.getTitle(), query))
                .collect(Collectors.toList());
    }

    private boolean containsIgnoreCase(String source, String target) {
        return source.toLowerCase().contains(target.toLowerCase());
    }


    public List<Book> searchBooksByTitle(String title) {
        // Retrieve all books from the repository
        List<Book> allBooks = bookRepo.findAll();
        
        // Filter books by title containing the search keyword (case-insensitive)
        List<Book> searchResults = allBooks.stream()
                .filter(book -> book.getTitle().toLowerCase().contains(title.toLowerCase()))
                .collect(Collectors.toList());
        
        return searchResults;
    }
}


