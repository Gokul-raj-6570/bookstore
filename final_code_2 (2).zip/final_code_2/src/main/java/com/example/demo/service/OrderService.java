//package com.example.demo.service;
//
//import com.example.demo.Entity.BookOrder;
//import com.example.demo.Entity.OrderItem;
//import com.example.demo.Repository.BookOrderRepository;
//import com.example.demo.Repository.OrderItemRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class OrderService {
//
//    @Autowired
//    private BookOrderRepository bookOrderRepository;
//
//    @Autowired
//    private OrderItemRepository orderItemRepository;
//
//    public void saveOrder(BookOrder bookOrder) {
//        bookOrderRepository.save(bookOrder);
//    }
//
//    public void saveOrderItems(List<OrderItem> orderItems) {
//        orderItemRepository.saveAll(orderItems);
//    }
//    
//    public List<BookOrder> getOrdersByUserId(Long userId) {
//        return bookOrderRepository.findByUserId(userId);
//    }
//}
package com.example.demo.service;

import com.example.demo.Entity.BookOrder;
import com.example.demo.Entity.BookOrderStatus;
import com.example.demo.Entity.OrderItem;
import com.example.demo.Repository.BookOrderRepository;
import com.example.demo.Repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private BookOrderRepository bookOrderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    public void saveOrder(BookOrder bookOrder) {
        bookOrderRepository.save(bookOrder);
    }

    public void saveOrderItems(List<OrderItem> orderItems) {
        orderItemRepository.saveAll(orderItems);
    }
    
    public List<BookOrder> getOrdersByUserId(Long userId) {
        return bookOrderRepository.findByUserId(userId);
    }
    public List<BookOrder> getAllOrders() {
        return bookOrderRepository.findAll();
    }

//    public void updateOrderStatus(Long orderId, BookOrderStatus status) {
//        Optional<BookOrder> optionalOrder = bookOrderRepository.findById(orderId);
//        if (optionalOrder.isPresent()) {
//            BookOrder order = optionalOrder.get();
//            order.setStatus(status);
//            bookOrderRepository.save(order);
//        }
//    }
    
    public void createOrder(BookOrder bookOrder) {
        if (bookOrder.getStatus() == null) {
            bookOrder.setStatus(BookOrderStatus.PENDING); // Set default status
        }
        bookOrderRepository.save(bookOrder);
    }

    public void updateOrderStatus(Long orderId, BookOrderStatus status) {
        BookOrder bookOrder = bookOrderRepository.findById(orderId).orElseThrow(() -> new IllegalArgumentException("Order not found"));
        bookOrder.setStatus(status);
        bookOrderRepository.save(bookOrder);
    }
}
