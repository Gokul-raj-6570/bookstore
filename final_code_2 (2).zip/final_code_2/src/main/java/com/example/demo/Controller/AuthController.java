//package com.example.demo.Controller;
//
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import com.example.demo.Entity.CartEntity;
//
//import com.example.demo.Entity.Book;
//import com.example.demo.Entity.BookOrder;
//import com.example.demo.Entity.CartItem;
//import com.example.demo.Entity.OrderItem;
//import com.example.demo.Entity.User;
//import com.example.demo.Repository.UserRepository;
//import com.example.demo.service.BookService;
//import com.example.demo.service.CartService;
//import com.example.demo.service.OrderService;
//import com.example.demo.service.UserService;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpSession;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//@Controller
//public class AuthController {
// 
//    @Autowired
//    private UserService userService;
//    
//    @Autowired
//    private UserRepository userRepository;
// 
//    @Autowired
//    private BookService bookService;
// 
//    @Autowired
//    private CartService cartService;
//    
//    @Autowired
//    private OrderService orderService;
// 
//    @GetMapping("/start")
//    public String showStartPage(HttpServletRequest request) {
//    	HttpSession session = request.getSession();
//        if (session.getAttribute("userId") == null) {
//            return "redirect:/home";
//        }
//        return "start";
//    }
// 
//    @GetMapping("/login")
//    public String showLoginForm() {
//        return "login";
//    }
//    
//	
//    @PostMapping("/place_order")
//    public String placeOrder(HttpServletRequest request, Model model) {
//        HttpSession session = request.getSession();
//        Long userId = (Long) session.getAttribute("userId");
// 
//        if (userId == null) {
//            return "redirect:/login";
//        }
// 
//        CartEntity cart = cartService.getCartByUserId(userId);
//        if (cart == null || cart.getItems().isEmpty()) {
//            model.addAttribute("message", "Your cart is empty.");
//            return "viewcart";
//        }
// 
//        // Calculate total price
//        double totalPrice = calculateTotalPrice(cart.getItems());
// 
//        // Save the total price in the session
//        session.setAttribute("totalPrice", totalPrice);
// 
//        // Redirect to the payment options page
//        return "redirect:/payment_options";
//    }
// 
// 
//    
//    @PostMapping("/login")
//    public String login(HttpServletRequest request, @ModelAttribute("user") User user, RedirectAttributes redirectAttributes) {
//    	User existingUser = userRepository.findByEmail(user.getEmail());
//        if (existingUser != null ) {
//            HttpSession session = request.getSession();
//            session.setAttribute("userId", existingUser.getId());
//            return "redirect:/home";
//        } else {
//            redirectAttributes.addFlashAttribute("errorMessage", "Invalid credentials. Please try again.");
//            return "redirect:/login";
//        }
//    }
// 
//    @GetMapping("/signup")
//    public String showSignupForm(Model model) {
//    	
//        model.addAttribute("user", new User());
//        return "signup";
//    }
// 
//    @PostMapping("/signup")
//    public String registerUser( @ModelAttribute User user, RedirectAttributes redirectAttributes) {
//        if (userService.getUserByEmail(user.getEmail()).isPresent()) {
//            redirectAttributes.addFlashAttribute("errorMessage", "User with this email already exists. Please log in.");
//            return "redirect:/login";
//        } else {
//            userService.addUser(user);
//            return "redirect:/login";
//        }
//    }
// 
//    @GetMapping("/home")
//    public String home() {
//        return "home";
//    }
// 
//    @GetMapping("/logout")
//    public String logout(HttpServletRequest request,Model model) {
//    	HttpSession session = request.getSession();
//        if (session.getAttribute("userId") == null) {
//            return "redirect:/home";
//        }
//        return "logout";
//    }
// 
//    @GetMapping("/showall_books")
//    public String viewCars(HttpServletRequest request,Model model) {
//    	HttpSession session = request.getSession();
//        if (session.getAttribute("userId") == null) {
//            return "redirect:/home";
//        }
//        List<Book> books = bookService.getBooks();
//        model.addAttribute("books", books);
//        return "showall_books";
//    }
//    
//    
//    
//    @PostMapping("/user/cart/add/{bookId}")
//    public String addToCart(HttpServletRequest request, @PathVariable Long bookId, Model model) {
//        HttpSession session = request.getSession();
//        Long userId = (Long) session.getAttribute("userId");
// 
//        if (userId == null) {
//            return "redirect:/login";
//        }
// 
//        Optional<User> optionalUser = userService.findById(userId);
//        if (optionalUser.isEmpty()) {
//            model.addAttribute("message", "User not found");
//            return "error";
//        }
//        User user = optionalUser.get();
// 
//        Optional<Book> optionalBook = bookService.findById(bookId);
//        if (optionalBook.isEmpty()) {
//            model.addAttribute("message", "Book not found");
//            return "error";
//        }
//        Book book = optionalBook.get();
// 
//        if (book.getQuantity() <= 0) {
//            model.addAttribute("message", "Out of stock");
//            return "out_of_stock";
//        }
// 
//        CartEntity cart = user.getShoppingCart();
//        if (cart == null) {
//            cart = new CartEntity(user);
//        }
// 
//        List<CartItem> items = cart.getItems();
//        boolean bookExistsInCart = false;
//       
// 
//        for (CartItem item : items) {
//            if (item.getBook().getId().equals(book.getId())) {
//                if (item.getQuantity() > book.getQuantity()) {
//                    model.addAttribute("message", "Quantity exceeds available stock");
//                    return "out_of_stock";
//                }
//                item.setQuantity(item.getQuantity() + 1);
//                book.setQuantity(book.getQuantity() - 1); // Decrease book quantity
//                bookService.updateBook(book); // Update book quantity in the database
//                bookExistsInCart = true;
//                break;
//            }
//        }
// 
//        if (!bookExistsInCart) {
//            CartItem newItem = new CartItem(book, 1);
//            cart.addItem(newItem);
//            book.setQuantity(book.getQuantity() - 1); // Decrease book quantity
//            bookService.updateBook(book); // Update book quantity in the database
//            
//        }
// 
//        cartService.save(cart);
//        model.addAttribute("message", "Item added to cart successfully");
//        
//        return "cart-success";
//    }
//    
//    
//    
//    // Method to calculate the total price of items in the cart
//    private double calculateTotalPrice(List<CartItem> items) {
//        double totalPrice = 0;
//        for (CartItem item : items) {
//            totalPrice += item.getQuantity() * item.getBook().getPrice();
//        }
//        return totalPrice;
//    }
//    @GetMapping("/orders")
//    public String viewOrders(HttpServletRequest request, Model model) {
//        HttpSession session = request.getSession();
//        Long userId = (Long) session.getAttribute("userId");
// 
//        if (userId == null) {
//            return "redirect:/login"; // Redirect to login if not logged in
//        }
// 
//        List<BookOrder> orders = orderService.getOrdersByUserId(userId);
//        model.addAttribute("orders", orders);
//        return "orders"; // Ensure this matches the name of your Thymeleaf template
//    }
// 
//    
//    @GetMapping("/viewcart")
//    public String viewCart(Model model, HttpServletRequest request) {
//        HttpSession session = request.getSession();
//        Long userId = (Long) session.getAttribute("userId");
//        if (userId == null) {
//            return "redirect:/home";
//        }
//        CartEntity cart = cartService.getCartByUserId(userId);
//        if (cart == null || cart.getItems().isEmpty()) {
//            model.addAttribute("message", "Your cart is empty.");
//        } else {
//            model.addAttribute("items", cart.getItems());
//            double totalPrice = calculateTotalPrice(cart.getItems()); // Calculate total price
//            model.addAttribute("totalPrice", totalPrice); // Add total price to the model
//        }
//        return "viewcart";
//    }
// 
//    @GetMapping("/payment_options")
//    public String showPaymentOptions(HttpServletRequest request, Model model) {
//        HttpSession session = request.getSession();
//        Long userId = (Long) session.getAttribute("userId");
// 
//        if (userId == null) {
//            return "redirect:/login";
//        }
// 
//        CartEntity cart = cartService.getCartByUserId(userId);
//        if (cart == null || cart.getItems().isEmpty()) {
//            model.addAttribute("message", "Your cart is empty.");
//            return "viewcart";
//        }
// 
//        double totalPrice = calculateTotalPrice(cart.getItems());
//        model.addAttribute("totalPrice", totalPrice);
// 
//        return "payment_options";
//    }
// 
//    @PostMapping("/confirm_order")
//    public String confirmOrder(HttpServletRequest request,
//                               @RequestParam("paymentMethod") String paymentMethod,
//                               @RequestParam("totalPrice") double totalPrice,
//                               Model model) {
//        HttpSession session = request.getSession();
//        Long userId = (Long) session.getAttribute("userId");
// 
//        if (userId == null) {
//            return "redirect:/login";
//        }
// 
//        Optional<User> optionalUser = userService.findById(userId);
//        if (optionalUser.isEmpty()) {
//            model.addAttribute("message", "User not found");
//            return "error";
//        }
//        User user = optionalUser.get();
// 
//        CartEntity cart = cartService.getCartByUserId(userId);
//        if (cart == null || cart.getItems().isEmpty()) {
//            model.addAttribute("message", "Your cart is empty.");
//            return "viewcart";
//        }
// 
//        // Create and save the order
//        BookOrder order = new BookOrder();
//        order.setUser(user);
//        order.setPaymentMethod(paymentMethod);
//        order.setTotalPrice(totalPrice); // Set the total price
// 
//        // Set order items
//        List<OrderItem> orderItems = new ArrayList<>();
//        for (CartItem cartItem : cart.getItems()) {
//            OrderItem orderItem = new OrderItem();
//            orderItem.setBook(cartItem.getBook());
//            orderItem.setQuantity(cartItem.getQuantity());
//            orderItem.setPrice(cartItem.getBook().getPrice());
//            orderItem.setOrder(order);
//            orderItems.add(orderItem);
//        }
//        order.setOrderItems(orderItems);
// 
//        orderService.saveOrder(order); // Save the order
//        cartService.clearCart(cart);
// 
//        model.addAttribute("message", "Order placed successfully");
//        return "order_success";
//    }
//    
//    
//    @DeleteMapping("/delete/{itemId}")
//    public String deleteFromCart(HttpServletRequest request, @PathVariable Long itemId, Model model) {
//        HttpSession session = request.getSession();
//        Long userId = (Long) session.getAttribute("userId");
// 
//        if (userId == null) {
//            return "redirect:/login";
//        }
// 
//        CartEntity cart = cartService.getCartByUserId(userId);
//        if (cart == null) {
//            model.addAttribute("message", "Your cart is empty.");
//            return "viewcart";
//        }
// 
//        CartItem itemToRemove = null;
//        for (CartItem item : cart.getItems()) {
//            if (item.getId().equals(itemId)) {
//                itemToRemove = item;
//                break;
//            }
//        }
// 
//        if (itemToRemove != null) {
//            cart.getItems().remove(itemToRemove);
//            cartService.save(cart);
// 
//            // Update the book quantity in the database
//            Book book = itemToRemove.getBook();
//            book.setQuantity(book.getQuantity() + itemToRemove.getQuantity());
//            bookService.updateBook(book);
//        }
// 
//        return "redirect:/viewcart"; // Redirect to update the view with the latest cart data
//    }
//}
package com.example.demo.Controller;
 
 
import com.example.demo.Entity.Book;
import com.example.demo.Entity.BookOrder;
import com.example.demo.Entity.CartEntity;
import com.example.demo.Entity.CartItem;
import com.example.demo.Entity.OrderItem;
import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRepository;
import com.example.demo.service.BookService;
import com.example.demo.service.CartService;
import com.example.demo.service.OrderService;
import com.example.demo.service.UserService;
 
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.mail.javamail.JavaMailSender;
 
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
 
@Controller
public class AuthController {
 
    @Autowired
    private UserService userService;
    
    @Autowired
    private UserRepository userRepository;
 
    @Autowired
    private BookService bookService;
 
    @Autowired
    private CartService cartService;
    
    @Autowired
    private OrderService orderService;
    
    @Autowired
    JavaMailSender javaMailSender;
 
    @GetMapping("/start")
    public String showStartPage(HttpServletRequest request) {
    	HttpSession session = request.getSession();
        if (session.getAttribute("userId") == null) {
            return "redirect:/home";
        }
        return "start";
    }
 
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }
    
    @GetMapping("/usersearch")
    public String searchBooks(@RequestParam("query") String query, Model model) {
        List<Book> searchResults = bookService.searchBooksByTitle(query);
        model.addAttribute("books", searchResults);
        return "book_list"; // Thymeleaf fragment containing book list
    }
    @PostMapping("/place_order")
    public String placeOrder(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Long userId = (Long) session.getAttribute("userId");
 
        if (userId == null) {
            return "redirect:/login";
        }
 
        CartEntity cart = cartService.getCartByUserId(userId);
        if (cart == null || cart.getItems().isEmpty()) {
            model.addAttribute("message", "Your cart is empty.");
            return "viewcart";
        }
 
        // Calculate total price
        double totalPrice = calculateTotalPrice(cart.getItems());
 
        // Save the total price in the session
        session.setAttribute("totalPrice", totalPrice);
 
        // Redirect to the payment options page
        return "redirect:/payment_options";
    }
 
 
    
    @PostMapping("/login")
    public String login(HttpServletRequest request, @ModelAttribute("user") User user, RedirectAttributes redirectAttributes) {
    	User existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser != null ) {
            HttpSession session = request.getSession();
            session.setAttribute("userId", existingUser.getId());
            return "redirect:/home";
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid credentials. Please try again.");
            return "redirect:/login";
        }
    }
 
    @GetMapping("/signup")
    public String showSignupForm(Model model) {
    	
        model.addAttribute("user", new User());
        return "signup";
    }
 
    @PostMapping("/signup")
    public String registerUser( @ModelAttribute User user, RedirectAttributes redirectAttributes) {
        if (userService.getUserByEmail(user.getEmail()).isPresent()) {
            redirectAttributes.addFlashAttribute("errorMessage", "User with this email already exists. Please log in.");
            return "redirect:/login";
        } else {
            userService.addUser(user);
            return "redirect:/login";
        }
    }
 
    @GetMapping("/home")
    public String home() {
        return "home";
    }
 
    @GetMapping("/logout")
    public String logout(HttpServletRequest request,Model model) {
    	HttpSession session = request.getSession();
        if (session.getAttribute("userId") == null) {
            return "redirect:/home";
        }
        return "logout";
    }
 
    @GetMapping("/showall_books")
    public String viewCars(HttpServletRequest request,Model model) {
    	HttpSession session = request.getSession();
        if (session.getAttribute("userId") == null) {
            return "redirect:/home";
        }
        List<Book> books = bookService.getBooks();
        model.addAttribute("books", books);
        return "showall_books";
    }
    
    
    
    @PostMapping("/user/cart/add/{bookId}")
    public String addToCart(HttpServletRequest request, @PathVariable Long bookId, Model model) {
        HttpSession session = request.getSession();
        Long userId = (Long) session.getAttribute("userId");
 
        if (userId == null) {
            return "redirect:/login";
        }
 
        Optional<User> optionalUser = userService.findById(userId);
        if (optionalUser.isEmpty()) {
            model.addAttribute("message", "User not found");
            return "error";
        }
        User user = optionalUser.get();
 
        Optional<Book> optionalBook = bookService.findById(bookId);
        if (optionalBook.isEmpty()) {
            model.addAttribute("message", "Book not found");
            return "error";
        }
        Book book = optionalBook.get();
 
        if (book.getQuantity() <= 0) {
            model.addAttribute("message", "Out of stock");
            return "out_of_stock";
        }
 
        CartEntity cart = user.getShoppingCart();
        if (cart == null) {
            cart = new CartEntity(user);
        }
 
        List<CartItem> items = cart.getItems();
        boolean bookExistsInCart = false;
       
 
        for (CartItem item : items) {
            if (item.getBook().getId().equals(book.getId())) {
                if (item.getQuantity() > book.getQuantity()) {
                    model.addAttribute("message", "Quantity exceeds available stock");
                    return "out_of_stock";
                }
                item.setQuantity(item.getQuantity() + 1);
                book.setQuantity(book.getQuantity() - 1); // Decrease book quantity
                bookService.updateBook(book); // Update book quantity in the database
                bookExistsInCart = true;
                break;
            }
        }
 
        if (!bookExistsInCart) {
            CartItem newItem = new CartItem(book, 1);
            cart.addItem(newItem);
            book.setQuantity(book.getQuantity() - 1); // Decrease book quantity
            bookService.updateBook(book); // Update book quantity in the database
            
        }
 
        cartService.save(cart);
        model.addAttribute("message", "Item added to cart successfully");
        
        return "cart-success";
    }
    
    
    
    // Method to calculate the total price of items in the cart
    private double calculateTotalPrice(List<CartItem> items) {
        double totalPrice = 0;
        for (CartItem item : items) {
            totalPrice += item.getQuantity() * item.getBook().getPrice();
        }
        return totalPrice;
    }
    @GetMapping("/orders")
    public String viewOrders(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Long userId = (Long) session.getAttribute("userId");
 
        if (userId == null) {
            return "redirect:/login"; // Redirect to login if not logged in
        }
 
        List<BookOrder> orders = orderService.getOrdersByUserId(userId);
        model.addAttribute("orders", orders);
        return "orders"; // Ensure this matches the name of your Thymeleaf template
    }
 
    
    @GetMapping("/viewcart")
    public String viewCart(Model model, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/home";
        }
        CartEntity cart = cartService.getCartByUserId(userId);
        if (cart == null || cart.getItems().isEmpty()) {
            model.addAttribute("message", "Your cart is empty.");
        } else {
            model.addAttribute("items", cart.getItems());
            double totalPrice = calculateTotalPrice(cart.getItems()); // Calculate total price
            model.addAttribute("totalPrice", totalPrice); // Add total price to the model
        }
        return "viewcart";
    }
 
    @GetMapping("/payment_options")
    public String showPaymentOptions(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession();
        Long userId = (Long) session.getAttribute("userId");
 
        if (userId == null) {
            return "redirect:/login";
        }
 
        CartEntity cart = cartService.getCartByUserId(userId);
        if (cart == null || cart.getItems().isEmpty()) {
            model.addAttribute("message", "Your cart is empty.");
            return "viewcart";
        }
 
        double totalPrice = calculateTotalPrice(cart.getItems());
        model.addAttribute("totalPrice", totalPrice);
 
        return "payment_options";
    }
 
    @PostMapping("/confirm_order")
    public String confirmOrder(HttpServletRequest request,
                               @RequestParam("paymentMethod") String paymentMethod,
                               @RequestParam("totalPrice") double totalPrice,
                               Model model) {
        HttpSession session = request.getSession();
        Long userId = (Long) session.getAttribute("userId");
 
        if (userId == null) {
            return "redirect:/login";
        }
 
        Optional<User> optionalUser = userService.findById(userId);
        if (optionalUser.isEmpty()) {
            model.addAttribute("message", "User not found");
            return "error";
        }
        User user = optionalUser.get();
 
        CartEntity cart = cartService.getCartByUserId(userId);
        if (cart == null || cart.getItems().isEmpty()) {
            model.addAttribute("message", "Your cart is empty.");
            return "viewcart";
        }
 
        // Create and save the order
        BookOrder order = new BookOrder();
        order.setUser(user);
        order.setPaymentMethod(paymentMethod);
        order.setTotalPrice(totalPrice); // Set the total price
 
        // Set order items
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cart.getItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setBook(cartItem.getBook());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(cartItem.getBook().getPrice());
            orderItem.setOrder(order);
            orderItems.add(orderItem);
        }
        order.setOrderItems(orderItems);
 
        orderService.saveOrder(order); // Save the order
        cartService.clearCart(cart);
        sendOrderConfirmationEmail(user, order);
 
		/*
		 * model.addAttribute("message", "Order placed successfully"); String from =
		 * "blazmoneymaking@gmail.com"; String to = user.getEmail(); SimpleMailMessage
		 * message = new SimpleMailMessage();
		 *
		 * message.setFrom(from); message.setTo(to);
		 * message.setSubject("Order placed successfully");
		 * message.setText(generateOrderEmailContent(order));
		 *
		 *
		 * javaMailSender.send(message);
		 */
        return "order_success";
    }
    
    
    private void sendOrderConfirmationEmail(User user, BookOrder order) {
        String from = "blazmoneymaking@gmail.com";
        String to = user.getEmail();
        
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject("Order Confirmation");
            helper.setText(generateOrderEmailContent(order), true); // true indicates HTML content
            javaMailSender.send(mimeMessage);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
    
    
    
	
	  private String generateOrderEmailContent(BookOrder order) { StringBuilder
	  emailContent = new StringBuilder(); emailContent.append("<!DOCTYPE html>")
	  .append("<html lang='en'>") .append("<head>") .append("<style>")
	  .append("body { font-family: Arial, sans-serif; background-color: #f0f0f0; color: #333; }"
	  )
	  .append(".container { max-width: 800px; margin: 20px auto; padding: 20px; background-color: #ffffff; border-radius: 10px; box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); }"
	  )
	  .append("header { background-color: #2c3e50; color: #ffffff; padding: 20px 0; font-size: 24px; text-align: center; }"
	  ) .append("table { width: 100%; border-collapse: collapse; }")
	  .append("th, td { padding: 10px; border-bottom: 1px solid #dddddd; text-align: left; }"
	  ) .append("th { background-color: #f2f2f2; }")
	  .append("tr:hover { background-color: #f5f5f5; }") .append("</style>")
	  .append("</head>") .append("<body>")
	  .append("<header>Order Confirmation</header>")
	  .append("<div class='container'>")
	  .append("<h2>Thank you for your order!</h2>") .append("<table>")
	  .append("<thead>") .append("<tr>") .append("<th>Order ID</th>")
	  .append("<th>Payment Method</th>") .append("<th>Total Price</th>")
	  .append("</tr>") .append("</thead>") .append("<tbody>") .append("<tr>")
	  .append("<td>").append(order.getId()).append("</td>")
	  .append("<td>").append(order.getPaymentMethod()).append("</td>")
	  .append("<td>").append(order.getTotalPrice()).append("</td>")
	  .append("</tr>") .append("</tbody>") .append("</table>")
	  .append("<h3>Order Items:</h3>") .append("<table>") .append("<thead>")
	  .append("<tr>") .append("<th>Book Title</th>") .append("<th>Quantity</th>")
	  .append("<th>Price</th>") .append("</tr>") .append("</thead>")
	  .append("<tbody>"); for (OrderItem item : order.getOrderItems()) {
	  emailContent.append("<tr>")
	  .append("<td>").append(item.getBook().getTitle()).append("</td>")
	  .append("<td>").append(item.getQuantity()).append("</td>")
	  .append("<td>").append(item.getPrice()).append("</td>") .append("</tr>"); }
	  emailContent.append("</tbody>") .append("</table>") .append("</div>")
	  .append("</body>") .append("</html>"); return emailContent.toString(); }
	
    
    
    @DeleteMapping("/delete/{itemId}")
    public String deleteFromCart(HttpServletRequest request, @PathVariable Long itemId, Model model) {
        HttpSession session = request.getSession();
        Long userId = (Long) session.getAttribute("userId");
 
        if (userId == null) {
            return "redirect:/login";
        }
 
        CartEntity cart = cartService.getCartByUserId(userId);
        if (cart == null) {
            model.addAttribute("message", "Your cart is empty.");
            return "viewcart";
        }
 
        CartItem itemToRemove = null;
        for (CartItem item : cart.getItems()) {
            if (item.getId().equals(itemId)) {
                itemToRemove = item;
                break;
            }
        }
 
        if (itemToRemove != null) {
            cart.getItems().remove(itemToRemove);
            cartService.save(cart);
 
            // Update the book quantity in the database
            Book book = itemToRemove.getBook();
            book.setQuantity(book.getQuantity() + itemToRemove.getQuantity());
            bookService.updateBook(book);
        }
 
        return "redirect:/viewcart"; // Redirect to update the view with the latest cart data
    }
 

    @GetMapping("/book/details/{bookId}")
    public String viewBookDetails(@PathVariable("bookId") Long bookId, Model model) {
        Book book = bookService.findById(bookId)
                               .orElseThrow();
        model.addAttribute("book", book);
        return "book-details";
    }
    
 }

    
 
 
 