package com.example.demo.Entity;
// 
//import jakarta.persistence.*;
//import java.util.List;
// 
//@Entity
//public class BookOrder {
// 
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
// 
//    @ManyToOne
//    @JoinColumn(name = "user_id", nullable = false)
//    private User user;
// 
//    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//    private List<OrderItem> orderItems;
//    private String paymentMethod;
//    private double totalPrice;
// 
//	public BookOrder() {
//		super();
//	}
// 
//	public BookOrder(Long id, User user, List<OrderItem> orderItems, int totalPrice) {
//		super();
//		this.id = id;
//		this.user = user;
//		this.orderItems = orderItems;
//		this.totalPrice = totalPrice;
//	}
// 
//	public Long getId() {
//		return id;
//	}
// 
//	public void setId(Long id) {
//		this.id = id;
//	}
// 
//	public User getUser() {
//		return user;
//	}
// 
//	public void setUser(User user) {
//		this.user = user;
//	}
// 
//	public List<OrderItem> getOrderItems() {
//		return orderItems;
//	}
// 
//	public void setOrderItems(List<OrderItem> orderItems) {
//		this.orderItems = orderItems;
//	}
//	public String getPaymentMethod() {
//        return paymentMethod;
//    }
//
//    public void setPaymentMethod(String paymentMethod) {
//        this.paymentMethod = paymentMethod;
//    }
//  
//  
//
//	public double getTotalPrice() {
//		return totalPrice;
//	}
//
//	public void setTotalPrice(double totalPrice) {
//		this.totalPrice = totalPrice;
//	}
//
//	@Override
//	public String toString() {
//		return "BookOrder [id=" + id + ", user=" + user + ", orderItems=" + orderItems + ", paymentMethod="
//				+ paymentMethod + ", totalPrice=" + totalPrice + "]";
//	}
//
//
//
// 
//	
//}




import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

import java.util.List;

@Entity
public class BookOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private double totalPrice;

    @Column(nullable = false)
    private String paymentMethod;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BookOrderStatus status = BookOrderStatus.PENDING;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<OrderItem> orderItems;

    

    public BookOrder() {
		super();
	}
    
    
	public BookOrder(Long id, User user, double totalPrice, String paymentMethod, BookOrderStatus status,
			List<OrderItem> orderItems) {
		super();
		this.id = id;
		this.user = user;
		this.totalPrice = totalPrice;
		this.paymentMethod = paymentMethod;
		this.status = status;
		this.orderItems = orderItems;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public double getTotalPrice() {
		return totalPrice;
	}


	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}


	public String getPaymentMethod() {
		return paymentMethod;
	}


	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}


	public List<OrderItem> getOrderItems() {
		return orderItems;
	}


	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}


	public BookOrderStatus getStatus() {
        return status;
    }

    public void setStatus(BookOrderStatus status) {
        this.status = status;
    }


	@Override
	public String toString() {
		return "BookOrder [id=" + id + ", user=" + user + ", totalPrice=" + totalPrice + ", paymentMethod="
				+ paymentMethod + ", status=" + status + ", orderItems=" + orderItems + "]";
	}
    
}
