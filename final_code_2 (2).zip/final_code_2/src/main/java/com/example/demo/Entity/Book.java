package com.example.demo.Entity;
 
import java.util.Arrays;
import java.util.Base64;
import java.util.Locale.Category;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Transient;
import lombok.Data;
 
@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bookid")
    private Long id;
 
    @Column
    private String title;
 
 
    @Column
    private String description;
 

	@Column
    private double price;
 
    @Column
    private int quantity;
 
	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "author_id") private Author author;
	 */
    private String author;
    
 
    @Lob
	@Column(name = "image", columnDefinition = "BLOB")
	private byte[] image;
 
	@Transient
	private String imageBase64;
 
	public Book() {
 
	}
 
	public Book(Long id, String title, String description, double price, int quantity, String author, byte[] image) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
		this.author = author;
		this.image = image;
	}
 
	public Long getId() {
		return id;
	}
 
	public void setId(Long id) {
		this.id = id;
	}
 
	public String getTitle() {
		return title;
	}
 
	public void setTitle(String title) {
		this.title = title;
	}
 
	public String getDescription() {
		return description;
	}
 
	public void setDescription(String description) {
		this.description = description;
	}
 
	public double getPrice() {
		return price;
	}
 
	public void setPrice(double price) {
		this.price = price;
	}
 
	public int getQuantity() {
		return quantity;
	}
 
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
 
	public String getAuthor() {
		return author;
	}
 
	public void setAuthor(String author) {
		this.author = author;
	}
 
	public byte[] getImage() {
		return image;
	}
 
	public void setImage(byte[] image) {
		this.image = image;
	}
 
	public String getImageBase64() {
		if (image != null && image.length > 0) {
			return Base64.getEncoder().encodeToString(image);
		} else {
			return null;
		}
	}
 
	public void setImageBase64(String imageBase64) {
		this.imageBase64 = imageBase64;
	}
 
 
}