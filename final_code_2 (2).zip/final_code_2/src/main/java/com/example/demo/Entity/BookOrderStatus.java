package com.example.demo.Entity;


public enum BookOrderStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    CANCELLED
}
